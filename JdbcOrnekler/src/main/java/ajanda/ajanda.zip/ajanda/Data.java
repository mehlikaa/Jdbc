package ajanda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class Data {

	static double saatler[] = { 08.00, 09.00, 10.00, 11.00, 12.00, 13.00, 14.00, 15.00, 16.00, 17.00, 18.00, 19.00 };
	static List<String> etkinlikler = new ArrayList<>(Arrays.asList("Piknik", "Tatil", "Is Gorusmesi", "Ozel Gorusme", "Seyahat", "Ziyaret","Diger"));
	static List<String> adSoyad = new ArrayList<>(Arrays.asList("Ahmet CALISKAN", "Mehmet DOGRU", "Ayse Nur GUZEL", "Hasan ARKAS", "Dilara HANCI"));
	static List<String> telefon = new ArrayList<>(Arrays.asList("0 555 555 55 51", "0 555 555 55 52","0 555 555 55 53","0 555 555 55 54","0 555 555 55 55"));
	static List<String> eMail = new ArrayList<>(Arrays.asList("ahmetcaliskan@gmail.com", "mehmetdogru@hotmail.com","aysenurguzel@yandex.com","hasanarkas@gmail.com","dilarahanci@hanci.com"));
	static List<String> adres = new ArrayList<>(Arrays.asList("Paris/Fransa", "İstanbul/ TÜRKİYE", "Hatay / TÜRKİYE", "İzmir / TÜRKİYE", "Almanya/"));
	
	
	
}
