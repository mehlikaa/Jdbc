package ajanda;

public class Ayarlar {


public void bildirimYaz(){
	
}

public static void bildirimYaz(String yazilacakIfade) {
	
	System.out.println(
			  "╔════════════════════════════════════════╗\r\n"
			+ "║  "+yazilacakIfade+  "\r\n"
			+ "╚════════════════════════════════════════╝\r\n");
}

}